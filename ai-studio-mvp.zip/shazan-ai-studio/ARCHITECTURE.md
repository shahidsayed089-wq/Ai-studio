# Architecture

## Product boundary

Shazan AI Studio does not train video models. It is an orchestration, commerce and workflow layer over authorized provider APIs.

## Request lifecycle

```text
Browser
  -> authenticated Next.js route
  -> input validation
  -> model catalog and cost calculator
  -> provider adapter
  -> provider accepts task
  -> atomic-style credit deduction and local job record
  -> browser polls platform job endpoint
  -> platform polls provider endpoint
  -> terminal result or one-time automatic refund
```

## Provider adapter contract

Every adapter implements three ideas:

```ts
configured(): boolean
create(input): provider task id
status(providerTaskId, job): normalized status and output
```

This keeps provider payloads outside the product UI. A model can be replaced, versioned or disabled without rewriting the creator dashboard.

## Normalized job states

- `queued`
- `processing`
- `completed`
- `failed`

Provider-specific states such as `dreaming`, `submitted`, `in_progress`, `succeed` and `error` are translated into this shared lifecycle.

## Credit ledger

The user balance is not reduced until the provider accepts the generation request. A transaction entry is written for each deduction, top-up and refund. A job can receive only one failure refund because terminal jobs are not polled again.

## Current MVP storage

The JSON store is deliberate for a zero-setup single-server MVP. It is easy to inspect and migrate, but it is not suitable for multiple server replicas.

Public launch migration:

```text
JSON file -> PostgreSQL
in-request polling -> Redis + BullMQ workers
provider URL -> Cloudflare R2 permanent asset
manual token -> workload identity
mock top-up -> Razorpay signed order and webhook
```

## Security boundaries

- API secrets remain server-only.
- Session cookies are HTTP-only and same-site.
- Passwords are hashed with bcrypt.
- Render content requires ownership checks.
- Input is validated with Zod.
- Credit calculation occurs on the server.
- Browser values are never trusted for cost or role.

## Scale target

The first production shape can run on one 2-vCPU VPS. Move to queue workers and Postgres when concurrent generations or multiple web replicas are introduced.
