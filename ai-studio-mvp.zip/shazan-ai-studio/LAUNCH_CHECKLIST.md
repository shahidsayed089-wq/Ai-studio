# Launch checklist

## Required

- Replace `AUTH_SECRET` with a random 32-byte or longer value.
- Turn off `ENABLE_DEMO_TOPUPS`.
- Connect Razorpay orders, signature verification and payment webhooks.
- Add PostgreSQL and transaction-safe credit locking.
- Add R2 or S3 permanent video storage.
- Add rate limiting for login, registration and generation routes.
- Add provider cost reconciliation.
- Add privacy policy, terms, refund policy and copyright takedown process.
- Add content moderation and prohibited-person / prohibited-content controls.
- Configure domain, TLS, backups and uptime monitoring.

## Provider acceptance tests

For every provider, test:

1. Text-to-video request
2. Image-to-video request when supported
3. Invalid prompt response
4. Insufficient provider balance
5. Provider timeout
6. Successful polling
7. Failed task and automatic refund
8. Output URL persistence
9. Rate-limit response
10. Cost comparison against the internal credit price

## Recommended launch sequence

1. Luma live
2. Kling live
3. Seedance live after enterprise approval
4. Veo live with workload identity and GCS signing
5. Sora live while keeping a replacement adapter ready
