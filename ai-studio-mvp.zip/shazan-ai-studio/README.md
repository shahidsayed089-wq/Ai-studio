# Shazan AI Studio

A deployable multi-model AI video generation MVP inspired by the unified workflow of products such as Higgsfield. It gives creators one interface for Sora, Veo, Luma, Kling and Seedance, with provider adapters, credits, job polling, automatic refunds, a render library and an admin command center.

## What is working

- Premium responsive landing page and mobile-first creator dashboard
- Email/password registration and secure signed-cookie sessions
- 80 welcome credits for new users
- Five selectable video engines
- Text-to-video and image-to-video controls
- Aspect ratio, duration, resolution and audio controls
- Cinematic prompt enhancer
- Real async provider job architecture
- Live status polling in the render library
- Automatic credit refund on failed generation
- Demo provider fallback for full end-to-end testing without API keys
- Real Sora and Luma API integrations
- Kling, Seedance and Veo production adapters with environment-based credentials
- Founder admin metrics and provider usage mix
- Docker and Docker Compose deployment

## Demo login

- Email: `creator@shazan.ai`
- Password: `demo1234`
- Starting balance: 350 credits

The database is created automatically on first server request.

## Start locally

```bash
cp .env.example .env
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production start

```bash
npm run build -- --webpack
npm start
```

Or:

```bash
cp .env.example .env
docker compose up --build -d
```

## Provider modes

Each provider is reported as one of:

- `live`: credentials are configured and real provider requests are used
- `demo`: credentials are missing and a realistic local render lifecycle is used
- `offline`: credentials are missing and demo fallback is disabled

Set `DEMO_PROVIDER_FALLBACK=false` before a strict production launch.

## Provider configuration

### Sora

Set `OPENAI_API_KEY`. The adapter creates a job with `POST /v1/videos`, checks it with `GET /v1/videos/{id}` and proxies completed content from `GET /v1/videos/{id}/content`.

### Luma

Set `LUMA_API_KEY`. The adapter uses the Dream Machine generation endpoint and supports text-to-video plus public image URL references.

### Kling

Set `KLING_ACCESS_KEY` and `KLING_SECRET_KEY`. The adapter creates short-lived HS256 JWT tokens and calls separate text-to-video or image-to-video task endpoints. Keep `KLING_API_BASE` and `KLING_MODEL` configurable because account regions and model identifiers may differ.

### Seedance

Set `BYTEPLUS_API_KEY`. The adapter targets the ModelArk content-generation task pattern. Confirm the exact model endpoint and model ID enabled for your BytePlus enterprise account before live launch.

### Veo

Set the Google Cloud project, location and OAuth access token. The MVP calls Vertex AI long-running prediction operations. For production, replace the environment access token with Google Workload Identity or a service-account token refresh layer.

## Credit safety flow

1. Validate the input and calculate cost.
2. Confirm the user has enough credits.
3. Ask the provider to create the job.
4. Deduct credits only after provider acceptance.
5. Poll provider status through the platform.
6. If the provider reports failure, refund the full cost once.

## Data layer

This MVP uses a JSON database at `data/db.json` to remain portable and runnable on one VPS with zero setup. Before public scale, replace `src/lib/db.ts` with PostgreSQL and use transactions or row locking for credit operations.

Recommended production upgrades:

- PostgreSQL with Prisma or Drizzle
- Redis and BullMQ workers
- Cloudflare R2 or S3 asset storage
- Razorpay order creation and webhook signature verification
- Provider webhooks instead of browser-driven polling
- Rate limiting and abuse detection
- Content moderation and copyright policy checks
- Sentry, OpenTelemetry and structured provider cost logs

## Architecture

```text
Creator dashboard
      |
Next.js route handlers
      |
Unified generation schema
      |
Provider registry
  | Sora | Veo | Luma | Kling | Seedance |
      |
Job state + credit ledger
      |
Render library and admin metrics
```

## Important launch notes

- Never expose provider API keys to the browser.
- Do not automate consumer subscriptions or shared browser accounts.
- Use only official API access or written enterprise authorization.
- Public image references must be hosted on a URL accessible to the selected provider.
- Replace demo billing before collecting money.
- Add terms, privacy policy, takedown flow and AI-generated media disclosure.
