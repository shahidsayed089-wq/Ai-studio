export type ProviderId = "sora" | "veo" | "luma" | "kling" | "seedance";
export type GenerationMode = "text-to-video" | "image-to-video";
export type GenerationStatus = "queued" | "processing" | "completed" | "failed";

export type UserRole = "user" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  credits: number;
  role: UserRole;
  createdAt: string;
}

export interface CreditTransaction {
  id: string;
  userId: string;
  amount: number;
  type: "topup" | "generation" | "refund";
  description: string;
  createdAt: string;
}

export interface GenerationInput {
  provider: ProviderId;
  model: string;
  prompt: string;
  negativePrompt?: string;
  mode: GenerationMode;
  imageUrl?: string;
  aspectRatio: "16:9" | "9:16" | "1:1";
  duration: 5 | 8 | 10 | 15;
  resolution: "720p" | "1080p";
  audio: boolean;
  seed?: number;
}

export interface GenerationJob extends GenerationInput {
  id: string;
  userId: string;
  status: GenerationStatus;
  progress: number;
  cost: number;
  providerJobId?: string;
  providerPayload?: Record<string, unknown>;
  outputUrl?: string;
  thumbnailUrl?: string;
  error?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DatabaseShape {
  users: User[];
  jobs: GenerationJob[];
  transactions: CreditTransaction[];
}

export interface ProviderCreateResult {
  providerJobId: string;
  status: GenerationStatus;
  progress?: number;
  raw?: Record<string, unknown>;
}

export interface ProviderStatusResult {
  status: GenerationStatus;
  progress: number;
  outputUrl?: string;
  thumbnailUrl?: string;
  error?: string;
  raw?: Record<string, unknown>;
}

export interface VideoProvider {
  id: ProviderId;
  configured(): boolean;
  create(input: GenerationInput): Promise<ProviderCreateResult>;
  status(providerJobId: string, job: GenerationJob): Promise<ProviderStatusResult>;
  content?(providerJobId: string): Promise<Response>;
}
