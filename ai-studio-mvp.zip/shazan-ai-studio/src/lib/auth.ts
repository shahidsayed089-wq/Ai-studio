import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
import { readDb } from "./db";

const COOKIE_NAME = "shazan_session";
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "dev-only-change-this-secret-before-production");

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret);

  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function clearSession() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function getSessionUserId() {
  try {
    const store = await cookies();
    const token = store.get(COOKIE_NAME)?.value;
    if (!token) return null;
    const payload = await jwtVerify(token, secret);
    return typeof payload.payload.userId === "string" ? payload.payload.userId : null;
  } catch {
    return null;
  }
}

export async function getCurrentUser() {
  const userId = await getSessionUserId();
  if (!userId) return null;
  const db = await readDb();
  const user = db.users.find((item) => item.id === userId);
  if (!user) return null;
  return { id: user.id, name: user.name, email: user.email, credits: user.credits, role: user.role, createdAt: user.createdAt };
}
