import type { GenerationInput, GenerationJob, ProviderCreateResult, ProviderStatusResult } from "../types";
import { BaseProvider } from "./base";

export class VeoProvider extends BaseProvider {
  id = "veo" as const;
  configured() { return Boolean(process.env.GOOGLE_CLOUD_PROJECT && process.env.GOOGLE_CLOUD_ACCESS_TOKEN); }

  private accessToken() {
    const token = process.env.GOOGLE_CLOUD_ACCESS_TOKEN;
    if (!token) throw new Error("GOOGLE_CLOUD_ACCESS_TOKEN is not configured");
    return token;
  }

  private endpoint(model: string, method: "predictLongRunning" | "fetchPredictOperation") {
    const project = process.env.GOOGLE_CLOUD_PROJECT;
    const location = process.env.GOOGLE_CLOUD_LOCATION || "us-central1";
    return `https://${location}-aiplatform.googleapis.com/v1/projects/${project}/locations/${location}/publishers/google/models/${model}:${method}`;
  }

  async create(input: GenerationInput): Promise<ProviderCreateResult> {
    const payload = {
      instances: [{ prompt: input.prompt }],
      parameters: {
        sampleCount: 1,
        durationSeconds: input.duration,
        aspectRatio: input.aspectRatio,
        generateAudio: input.audio,
        resolution: input.resolution,
        ...(process.env.GOOGLE_VIDEO_GCS_URI ? { storageUri: process.env.GOOGLE_VIDEO_GCS_URI } : {}),
      },
    };
    const body = await this.requestJson(this.endpoint(input.model, "predictLongRunning"), {
      method: "POST",
      headers: { Authorization: `Bearer ${this.accessToken()}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return { providerJobId: String(body.name || body.operationName), status: "queued", progress: 5, raw: body };
  }

  async status(providerJobId: string, job: GenerationJob): Promise<ProviderStatusResult> {
    const body = await this.requestJson(this.endpoint(job.model, "fetchPredictOperation"), {
      method: "POST",
      headers: { Authorization: `Bearer ${this.accessToken()}`, "Content-Type": "application/json" },
      body: JSON.stringify({ operationName: providerJobId }),
    });
    if (body.error) return { status: "failed", progress: 100, error: JSON.stringify(body.error), raw: body };
    if (body.done === true) {
      const response = (body.response || {}) as Record<string, unknown>;
      const videos = Array.isArray(response.videos) ? response.videos as Record<string, unknown>[] : [];
      const gcsUri = typeof videos[0]?.gcsUri === "string" ? videos[0].gcsUri : undefined;
      const url = gcsUri?.startsWith("gs://") ? `https://storage.googleapis.com/${gcsUri.slice(5)}` : gcsUri;
      return { status: "completed", progress: 100, outputUrl: url, raw: body };
    }
    return { status: "processing", progress: 50, raw: body };
  }
}
