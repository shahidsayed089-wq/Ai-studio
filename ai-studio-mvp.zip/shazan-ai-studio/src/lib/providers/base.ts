import type { GenerationInput, GenerationJob, ProviderCreateResult, ProviderStatusResult, VideoProvider } from "../types";

export abstract class BaseProvider implements VideoProvider {
  abstract id: VideoProvider["id"];
  abstract configured(): boolean;
  abstract create(input: GenerationInput): Promise<ProviderCreateResult>;
  abstract status(providerJobId: string, job: GenerationJob): Promise<ProviderStatusResult>;

  protected async requestJson(url: string, init: RequestInit) {
    const response = await fetch(url, { ...init, cache: "no-store" });
    const text = await response.text();
    let body: Record<string, unknown> = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = { message: text };
    }
    if (!response.ok) {
      const message = typeof body.message === "string" ? body.message : `Provider request failed (${response.status})`;
      throw new Error(message);
    }
    return body;
  }
}
