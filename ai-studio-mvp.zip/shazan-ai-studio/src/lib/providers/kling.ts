import { SignJWT } from "jose";
import type { GenerationInput, GenerationJob, ProviderCreateResult, ProviderStatusResult } from "../types";
import { BaseProvider } from "./base";

export class KlingProvider extends BaseProvider {
  id = "kling" as const;
  private base = process.env.KLING_API_BASE || "https://api.klingai.com";
  configured() { return Boolean(process.env.KLING_ACCESS_KEY && process.env.KLING_SECRET_KEY); }

  private async token() {
    const secret = new TextEncoder().encode(process.env.KLING_SECRET_KEY!);
    const now = Math.floor(Date.now() / 1000);
    return new SignJWT({})
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setIssuer(process.env.KLING_ACCESS_KEY!)
      .setNotBefore(now - 5)
      .setExpirationTime(now + 1800)
      .sign(secret);
  }

  async create(input: GenerationInput): Promise<ProviderCreateResult> {
    const modePath = input.mode === "image-to-video" ? "image2video" : "text2video";
    const payload: Record<string, unknown> = {
      model_name: process.env.KLING_MODEL || "kling-v3",
      prompt: input.prompt,
      negative_prompt: input.negativePrompt || "blur, flicker, deformed anatomy, watermark, text",
      mode: input.resolution === "1080p" ? "pro" : "std",
      aspect_ratio: input.aspectRatio,
      duration: String(input.duration),
    };
    if (input.imageUrl) payload.image = input.imageUrl;
    const body = await this.requestJson(`${this.base}/v1/videos/${modePath}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${await this.token()}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = (body.data || {}) as Record<string, unknown>;
    return { providerJobId: String(data.task_id || body.task_id), status: "queued", progress: 5, raw: body };
  }

  async status(providerJobId: string, job: GenerationJob): Promise<ProviderStatusResult> {
    const modePath = job.mode === "image-to-video" ? "image2video" : "text2video";
    const body = await this.requestJson(`${this.base}/v1/videos/${modePath}/${providerJobId}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${await this.token()}` },
    });
    const data = (body.data || body) as Record<string, unknown>;
    const state = String(data.task_status || data.status || "submitted");
    if (["failed", "error"].includes(state)) return { status: "failed", progress: 100, error: String(data.task_status_msg || "Kling generation failed"), raw: body };
    if (["succeed", "completed", "success"].includes(state)) {
      const result = (data.task_result || {}) as Record<string, unknown>;
      const videos = Array.isArray(result.videos) ? result.videos as Record<string, unknown>[] : [];
      return { status: "completed", progress: 100, outputUrl: typeof videos[0]?.url === "string" ? videos[0].url : undefined, raw: body };
    }
    return { status: "processing", progress: 52, raw: body };
  }
}
