import type { GenerationInput, ProviderCreateResult, ProviderStatusResult } from "../types";
import { BaseProvider } from "./base";

export class SoraProvider extends BaseProvider {
  id = "sora" as const;
  configured() { return Boolean(process.env.OPENAI_API_KEY); }

  async create(input: GenerationInput): Promise<ProviderCreateResult> {
    const form = new FormData();
    form.set("model", input.model || "sora-2-pro");
    form.set("prompt", input.prompt);
    form.set("seconds", String(input.duration));
    const size = input.aspectRatio === "9:16" ? "720x1280" : input.aspectRatio === "1:1" ? "1024x1024" : input.resolution === "1080p" ? "1920x1080" : "1280x720";
    form.set("size", size);
    const body = await this.requestJson("https://api.openai.com/v1/videos", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: form,
    });
    return { providerJobId: String(body.id), status: "queued", progress: Number(body.progress || 0), raw: body };
  }

  async status(providerJobId: string): Promise<ProviderStatusResult> {
    const body = await this.requestJson(`https://api.openai.com/v1/videos/${providerJobId}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
    });
    const status = String(body.status || "queued");
    if (status === "failed") {
      const error = (body.error || {}) as Record<string, unknown>;
      return { status: "failed", progress: 100, error: String(error.message || "Sora generation failed"), raw: body };
    }
    if (status === "completed") return { status: "completed", progress: 100, raw: body };
    return { status: status === "in_progress" ? "processing" : "queued", progress: Number(body.progress || 8), raw: body };
  }

  async content(providerJobId: string) {
    return fetch(`https://api.openai.com/v1/videos/${providerJobId}/content`, {
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      cache: "no-store",
    });
  }
}
