import type { ProviderId, VideoProvider } from "../types";
import { DemoProvider } from "./demo";
import { KlingProvider } from "./kling";
import { LumaProvider } from "./luma";
import { SeedanceProvider } from "./seedance";
import { SoraProvider } from "./sora";
import { VeoProvider } from "./veo";

const realProviders: Record<ProviderId, VideoProvider> = {
  sora: new SoraProvider(),
  veo: new VeoProvider(),
  luma: new LumaProvider(),
  kling: new KlingProvider(),
  seedance: new SeedanceProvider(),
};

export function getProvider(id: ProviderId): VideoProvider {
  const provider = realProviders[id];
  const demoFallback = process.env.DEMO_PROVIDER_FALLBACK !== "false";
  if (!provider.configured() && demoFallback) return new DemoProvider(id);
  return provider;
}

export function providerAvailability() {
  return Object.fromEntries(
    Object.entries(realProviders).map(([id, provider]) => [id, {
      configured: provider.configured(),
      mode: provider.configured() ? "live" : process.env.DEMO_PROVIDER_FALLBACK !== "false" ? "demo" : "offline",
    }]),
  );
}
