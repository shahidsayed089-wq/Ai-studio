import type { GenerationInput, ProviderCreateResult, ProviderStatusResult } from "../types";
import { BaseProvider } from "./base";

export class SeedanceProvider extends BaseProvider {
  id = "seedance" as const;
  private base = process.env.BYTEPLUS_API_BASE || "https://ark.ap-southeast.bytepluses.com/api/v3";
  configured() { return Boolean(process.env.BYTEPLUS_API_KEY); }

  async create(input: GenerationInput): Promise<ProviderCreateResult> {
    const content: Record<string, unknown>[] = [{ type: "text", text: input.prompt }];
    if (input.imageUrl) content.push({ type: "image_url", image_url: { url: input.imageUrl } });
    const payload = {
      model: process.env.SEEDANCE_MODEL || "seedance-2.0",
      content,
      ratio: input.aspectRatio,
      duration: input.duration,
      resolution: input.resolution,
      generate_audio: input.audio,
    };
    const body = await this.requestJson(`${this.base}/contents/generations/tasks`, {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.BYTEPLUS_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return { providerJobId: String(body.id || body.task_id), status: "queued", progress: 5, raw: body };
  }

  async status(providerJobId: string): Promise<ProviderStatusResult> {
    const body = await this.requestJson(`${this.base}/contents/generations/tasks/${providerJobId}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${process.env.BYTEPLUS_API_KEY}` },
    });
    const state = String(body.status || "queued").toLowerCase();
    if (["failed", "error"].includes(state)) return { status: "failed", progress: 100, error: String(body.error || "Seedance generation failed"), raw: body };
    if (["succeeded", "completed", "success"].includes(state)) {
      const content = (body.content || body.output || {}) as Record<string, unknown>;
      const videoUrl = typeof content.video_url === "string" ? content.video_url : typeof body.video_url === "string" ? body.video_url : undefined;
      return { status: "completed", progress: 100, outputUrl: videoUrl, raw: body };
    }
    return { status: "processing", progress: Number(body.progress || 48), raw: body };
  }
}
