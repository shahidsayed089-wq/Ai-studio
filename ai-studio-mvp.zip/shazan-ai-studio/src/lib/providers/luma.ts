import type { GenerationInput, ProviderCreateResult, ProviderStatusResult } from "../types";
import { BaseProvider } from "./base";

export class LumaProvider extends BaseProvider {
  id = "luma" as const;
  private base = process.env.LUMA_API_BASE || "https://api.lumalabs.ai/dream-machine/v1";
  configured() { return Boolean(process.env.LUMA_API_KEY); }

  async create(input: GenerationInput): Promise<ProviderCreateResult> {
    const payload: Record<string, unknown> = {
      prompt: input.prompt,
      model: input.model === "ray-2" ? "ray-2" : input.model,
      aspect_ratio: input.aspectRatio,
      resolution: input.resolution,
      duration: `${input.duration}s`,
      loop: false,
    };
    if (input.mode === "image-to-video" && input.imageUrl) {
      payload.keyframes = { frame0: { type: "image", url: input.imageUrl } };
    }
    const body = await this.requestJson(`${this.base}/generations`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.LUMA_API_KEY}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    });
    return {
      providerJobId: String(body.id),
      status: body.state === "completed" ? "completed" : "queued",
      progress: 5,
      raw: body,
    };
  }

  async status(providerJobId: string): Promise<ProviderStatusResult> {
    const body = await this.requestJson(`${this.base}/generations/${providerJobId}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${process.env.LUMA_API_KEY}`, Accept: "application/json" },
    });
    const state = String(body.state || "dreaming");
    if (state === "failed") return { status: "failed", progress: 100, error: String(body.failure_reason || "Luma generation failed"), raw: body };
    if (state === "completed") {
      const assets = (body.assets || {}) as Record<string, unknown>;
      return { status: "completed", progress: 100, outputUrl: typeof assets.video === "string" ? assets.video : undefined, raw: body };
    }
    return { status: "processing", progress: 55, raw: body };
  }
}
