import type { GenerationJob, ProviderCreateResult, ProviderStatusResult, ProviderId } from "../types";
import { BaseProvider } from "./base";

export class DemoProvider extends BaseProvider {
  id: ProviderId;
  constructor(id: ProviderId) {
    super();
    this.id = id;
  }
  configured() { return true; }
  async create(): Promise<ProviderCreateResult> {
    return { providerJobId: `demo_${this.id}_${Date.now()}`, status: "queued", progress: 5 };
  }
  async status(_providerJobId: string, job: GenerationJob): Promise<ProviderStatusResult> {
    const age = Date.now() - new Date(job.createdAt).getTime();
    if (age < 2500) return { status: "queued", progress: 12 };
    if (age < 6000) return { status: "processing", progress: Math.min(88, Math.round(20 + age / 80)) };
    return { status: "completed", progress: 100, outputUrl: "/media/demo-render.mp4" };
  }
}
