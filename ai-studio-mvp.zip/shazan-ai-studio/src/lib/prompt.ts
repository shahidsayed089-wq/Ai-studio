export function enhancePrompt(prompt: string, aspectRatio: string) {
  const clean = prompt.trim().replace(/\s+/g, " ");
  if (!clean) return "";
  const format = aspectRatio === "9:16" ? "vertical cinematic composition" : aspectRatio === "1:1" ? "square editorial composition" : "widescreen cinematic composition";
  return `${clean}. ${format}, coherent subject identity, physically grounded movement, intentional blocking, rich production design, natural skin texture, realistic lens behavior, cinematic depth of field, controlled highlights, subtle film grain, premium color separation, no text, no watermark, no deformed anatomy, no flicker.`;
}
