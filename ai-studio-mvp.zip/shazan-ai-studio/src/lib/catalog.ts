import type { GenerationInput, ProviderId } from "./types";

export type ModelDefinition = {
  id: string;
  provider: ProviderId;
  name: string;
  label: string;
  description: string;
  badge: string;
  strengths: string[];
  supportsAudio: boolean;
  supportsImage: boolean;
  durations: number[];
  baseCredits: number;
  gradient: string;
};

export const MODELS: ModelDefinition[] = [
  {
    id: "sora-2-pro",
    provider: "sora",
    name: "Sora 2 Pro",
    label: "Cinematic intelligence",
    description: "Complex scene logic, controlled motion and premium text-to-video output.",
    badge: "PREMIUM",
    strengths: ["Narrative motion", "Scene logic", "1080p"],
    supportsAudio: false,
    supportsImage: true,
    durations: [8, 10],
    baseCredits: 48,
    gradient: "from-fuchsia-500/25 via-violet-500/15 to-transparent",
  },
  {
    id: "veo-3.1-generate-preview",
    provider: "veo",
    name: "Veo 3.1",
    label: "Native audio cinema",
    description: "High-end video generation with audio, dialogue and realistic environmental sound.",
    badge: "AUDIO",
    strengths: ["Native sound", "Physics", "Prompt fidelity"],
    supportsAudio: true,
    supportsImage: true,
    durations: [8],
    baseCredits: 42,
    gradient: "from-blue-500/25 via-cyan-500/10 to-transparent",
  },
  {
    id: "ray-2",
    provider: "luma",
    name: "Luma Ray 2",
    label: "Fast visual poetry",
    description: "Reliable text and image animation with elegant camera movement and quick delivery.",
    badge: "LIVE API",
    strengths: ["Camera motion", "Image-to-video", "Fast"],
    supportsAudio: false,
    supportsImage: true,
    durations: [5, 10],
    baseCredits: 22,
    gradient: "from-orange-500/25 via-amber-500/10 to-transparent",
  },
  {
    id: "kling-v3",
    provider: "kling",
    name: "Kling 3.0",
    label: "Character consistency",
    description: "Grounded motion, strong subject preservation and cinematic action performance.",
    badge: "CONSISTENCY",
    strengths: ["Humans", "Action", "References"],
    supportsAudio: false,
    supportsImage: true,
    durations: [5, 10],
    baseCredits: 16,
    gradient: "from-red-500/25 via-rose-500/10 to-transparent",
  },
  {
    id: "seedance-2.0",
    provider: "seedance",
    name: "Seedance 2.0",
    label: "Multimodal director",
    description: "Flexible multi-shot generation with strong movement and reference-driven control.",
    badge: "MULTIMODAL",
    strengths: ["Multi-shot", "Motion", "Fast renders"],
    supportsAudio: true,
    supportsImage: true,
    durations: [5, 8, 10, 15],
    baseCredits: 14,
    gradient: "from-emerald-500/25 via-teal-500/10 to-transparent",
  },
];

export function getModel(id: string) {
  return MODELS.find((model) => model.id === id) ?? MODELS[2];
}

export function calculateCost(input: Pick<GenerationInput, "model" | "duration" | "resolution" | "audio">) {
  const model = getModel(input.model);
  const durationMultiplier = input.duration / Math.min(...model.durations);
  const resolutionMultiplier = input.resolution === "1080p" ? 1.35 : 1;
  const audioMultiplier = input.audio && model.supportsAudio ? 1.2 : 1;
  return Math.ceil(model.baseCredits * durationMultiplier * resolutionMultiplier * audioMultiplier);
}

export const CREDIT_PACKS = [
  { id: "spark", name: "Spark", credits: 120, price: 999, bonus: 0 },
  { id: "creator", name: "Creator", credits: 420, price: 2999, bonus: 40 },
  { id: "studio", name: "Studio", credits: 1200, price: 7499, bonus: 200 },
];
