import fs from "node:fs/promises";
import path from "node:path";
import bcrypt from "bcryptjs";
import type { DatabaseShape } from "./types";

const DB_PATH = path.join(process.cwd(), "data", "db.json");
let writeQueue = Promise.resolve();

async function seedDatabase(): Promise<DatabaseShape> {
  const now = new Date().toISOString();
  return {
    users: [
      {
        id: "user_demo_creator",
        name: "Shazan Creator",
        email: "creator@shazan.ai",
        passwordHash: await bcrypt.hash("demo1234", 10),
        credits: 350,
        role: "admin",
        createdAt: now,
      },
    ],
    jobs: [],
    transactions: [
      {
        id: "tx_welcome",
        userId: "user_demo_creator",
        amount: 350,
        type: "topup",
        description: "Founder launch credits",
        createdAt: now,
      },
    ],
  };
}

export async function readDb(): Promise<DatabaseShape> {
  try {
    const raw = await fs.readFile(DB_PATH, "utf8");
    return JSON.parse(raw) as DatabaseShape;
  } catch {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    const seeded = await seedDatabase();
    await fs.writeFile(DB_PATH, JSON.stringify(seeded, null, 2));
    return seeded;
  }
}

export async function mutateDb<T>(mutation: (db: DatabaseShape) => T | Promise<T>): Promise<T> {
  let resolveResult!: (value: T) => void;
  let rejectResult!: (reason?: unknown) => void;
  const resultPromise = new Promise<T>((resolve, reject) => {
    resolveResult = resolve;
    rejectResult = reject;
  });

  writeQueue = writeQueue.then(async () => {
    try {
      const db = await readDb();
      const result = await mutation(db);
      await fs.writeFile(DB_PATH, JSON.stringify(db, null, 2));
      resolveResult(result);
    } catch (error) {
      rejectResult(error);
    }
  });

  await writeQueue;
  return resultPromise;
}
