"use client";

import { useEffect, useState } from "react";
import { Activity, CircleDollarSign, Film, Loader2, Users } from "lucide-react";
import type { GenerationJob } from "@/lib/types";

type Metrics = { users: number; generations: number; completed: number; failed: number; creditsSpent: number; successRate: number; byProvider: Record<string, number> };

export function AdminClient() {
  const [data, setData] = useState<{ metrics: Metrics; recentJobs: GenerationJob[] } | null>(null);
  useEffect(() => { fetch("/api/admin/metrics").then((r) => r.json()).then(setData); }, []);
  if (!data) return <div className="grid min-h-screen place-items-center"><Loader2 className="animate-spin" /></div>;
  const cards = [
    { label: "Users", value: data.metrics.users, icon: Users },
    { label: "Generations", value: data.metrics.generations, icon: Film },
    { label: "Success rate", value: `${data.metrics.successRate}%`, icon: Activity },
    { label: "Credits spent", value: data.metrics.creditsSpent, icon: CircleDollarSign },
  ];
  const max = Math.max(1, ...Object.values(data.metrics.byProvider));
  return <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-7 lg:px-10 lg:py-12"><div><p className="text-xs font-black uppercase tracking-[0.18em] text-violet-300">Founder command center</p><h1 className="mt-3 text-4xl font-black tracking-[-0.04em]">Production pulse</h1></div><div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map((card) => <div key={card.label} className="rounded-3xl border border-white/[0.08] bg-white/[0.035] p-6"><card.icon className="size-5 text-white/35" /><p className="mt-7 text-4xl font-black">{card.value}</p><p className="mt-2 text-xs font-bold uppercase tracking-[0.14em] text-white/30">{card.label}</p></div>)}</div><div className="mt-6 grid gap-6 xl:grid-cols-[.8fr_1.2fr]"><section className="rounded-[2rem] border border-white/[0.08] bg-white/[0.03] p-6"><h2 className="font-black">Provider mix</h2><div className="mt-7 space-y-5">{Object.entries(data.metrics.byProvider).map(([name, value]) => <div key={name}><div className="mb-2 flex justify-between text-xs font-bold capitalize"><span>{name}</span><span className="text-white/35">{value}</span></div><div className="h-2 rounded-full bg-white/[0.06]"><div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-cyan-400" style={{ width: `${(value / max) * 100}%` }} /></div></div>)}</div></section><section className="overflow-hidden rounded-[2rem] border border-white/[0.08] bg-white/[0.03]"><div className="border-b border-white/[0.07] p-6"><h2 className="font-black">Latest jobs</h2></div><div className="divide-y divide-white/[0.06]">{data.recentJobs.length ? data.recentJobs.map((job) => <div key={job.id} className="flex items-center justify-between gap-4 p-5"><div className="min-w-0"><p className="truncate text-sm font-bold capitalize">{job.provider} • {job.model}</p><p className="mt-1 truncate text-xs text-white/30">{job.prompt}</p></div><span className={`rounded-full px-3 py-1 text-[10px] font-black uppercase ${job.status === "completed" ? "bg-emerald-500/10 text-emerald-300" : job.status === "failed" ? "bg-red-500/10 text-red-300" : "bg-amber-500/10 text-amber-200"}`}>{job.status}</span></div>) : <p className="p-6 text-sm text-white/35">No jobs yet.</p>}</div></section></div></div>;
}
