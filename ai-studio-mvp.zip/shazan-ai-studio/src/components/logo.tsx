import { Clapperboard } from "lucide-react";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="grid size-10 place-items-center rounded-2xl border border-white/15 bg-white/[0.08] shadow-[0_0_40px_rgba(147,51,234,.28)]">
        <Clapperboard className="size-5 text-violet-300" />
      </div>
      {!compact && (
        <div className="leading-none">
          <div className="text-sm font-black tracking-[0.18em] text-white">SHAZAN</div>
          <div className="mt-1 text-[10px] font-semibold tracking-[0.28em] text-white/40">AI STUDIO</div>
        </div>
      )}
    </div>
  );
}
