"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { ArrowRight, Loader2, LockKeyhole, Mail, User } from "lucide-react";

export function LoginClient() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "creator@shazan.ai", password: "demo1234" });

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setLoading(true); setError("");
    const response = await fetch(`/api/auth/${mode}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await response.json();
    setLoading(false);
    if (!response.ok) return setError(data.error || "Could not continue");
    router.push("/studio"); router.refresh();
  }

  return (
    <div className="w-full max-w-md rounded-[2rem] border border-white/10 bg-white/[0.045] p-6 shadow-2xl backdrop-blur-2xl sm:p-8">
      <div className="mb-8 flex rounded-2xl bg-black/25 p-1">
        {(["login", "register"] as const).map((item) => <button key={item} onClick={() => setMode(item)} className={`flex-1 rounded-xl py-2.5 text-sm font-bold capitalize transition ${mode === item ? "bg-white text-black" : "text-white/40"}`}>{item}</button>)}
      </div>
      <h1 className="text-3xl font-black tracking-tight">{mode === "login" ? "Enter the studio" : "Create your account"}</h1>
      <p className="mt-2 text-sm leading-6 text-white/45">One dashboard. Five world-class video engines. Your prompts, your credits, your production line.</p>
      <form onSubmit={submit} className="mt-7 space-y-4">
        {mode === "register" && <Field icon={<User />} placeholder="Your name" value={form.name} onChange={(value) => setForm({ ...form, name: value })} />}
        <Field icon={<Mail />} type="email" placeholder="Email" value={form.email} onChange={(value) => setForm({ ...form, email: value })} />
        <Field icon={<LockKeyhole />} type="password" placeholder="Password" value={form.password} onChange={(value) => setForm({ ...form, password: value })} />
        {error && <div className="rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</div>}
        <button disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-white px-5 py-3.5 font-black text-black transition hover:scale-[1.01] disabled:opacity-60">
          {loading ? <Loader2 className="size-4 animate-spin" /> : <>Continue <ArrowRight className="size-4" /></>}
        </button>
      </form>
      <div className="mt-6 rounded-2xl border border-violet-400/15 bg-violet-500/[0.07] p-4 text-xs leading-5 text-white/50">
        Demo account is prefilled. It starts with 350 credits and admin access.
      </div>
    </div>
  );
}

function Field({ icon, type = "text", placeholder, value, onChange }: { icon: React.ReactNode; type?: string; placeholder: string; value: string; onChange: (value: string) => void }) {
  return <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/25 px-4 py-3.5 text-white/35 focus-within:border-violet-400/40">{icon}<input required type={type} placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/25" /></label>;
}
