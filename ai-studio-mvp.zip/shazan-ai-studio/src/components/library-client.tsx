"use client";

import { useEffect, useMemo, useState } from "react";
import { Download, Film, Loader2, Play, RefreshCw, Search, TriangleAlert } from "lucide-react";
import type { GenerationJob } from "@/lib/types";
import { getModel } from "@/lib/catalog";

export function LibraryClient() {
  const [jobs, setJobs] = useState<GenerationJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  async function load() {
    const response = await fetch("/api/generations", { cache: "no-store" });
    const data = await response.json();
    if (response.ok) setJobs(data.jobs);
    setLoading(false);
  }

  useEffect(() => {
    void fetch("/api/generations", { cache: "no-store" })
      .then((response) => response.json())
      .then((data) => { if (data.jobs) setJobs(data.jobs); })
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    const active = jobs.filter((job) => ["queued", "processing"].includes(job.status));
    if (!active.length) return;
    const timer = setInterval(async () => {
      const updates = await Promise.all(active.map((job) => fetch(`/api/generations/${job.id}`, { cache: "no-store" }).then((r) => r.json())));
      setJobs((current) => current.map((job) => updates.find((item) => item.job?.id === job.id)?.job || job));
    }, 3000);
    return () => clearInterval(timer);
  }, [jobs]);

  const filtered = useMemo(() => jobs.filter((job) => `${job.prompt} ${job.provider}`.toLowerCase().includes(query.toLowerCase())), [jobs, query]);

  return <div className="mx-auto max-w-[1500px] px-4 py-7 sm:px-7 lg:px-10 lg:py-10">
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><h1 className="text-4xl font-black tracking-[-0.04em]">Render library</h1><p className="mt-2 text-sm text-white/40">Every frame, every provider, every status in one vault.</p></div><button onClick={load} className="flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2 text-sm font-bold text-white/55"><RefreshCw className="size-4" />Refresh</button></div>
    <label className="mt-7 flex max-w-xl items-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.035] px-4 py-3"><Search className="size-4 text-white/30" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search prompts or models" className="w-full bg-transparent text-sm outline-none placeholder:text-white/25" /></label>
    {loading ? <div className="grid min-h-80 place-items-center"><Loader2 className="animate-spin text-white/40" /></div> : !filtered.length ? <div className="mt-8 grid min-h-80 place-items-center rounded-[2rem] border border-dashed border-white/10"><div className="text-center"><Film className="mx-auto size-10 text-white/20" /><p className="mt-4 font-bold">No renders yet</p><p className="mt-1 text-sm text-white/35">Your first cinematic experiment will appear here.</p></div></div> : <div className="mt-8 grid gap-5 md:grid-cols-2 2xl:grid-cols-3">{filtered.map((job) => <JobCard key={job.id} job={job} />)}</div>}
  </div>;
}

function JobCard({ job }: { job: GenerationJob }) {
  const model = getModel(job.model);
  const active = ["queued", "processing"].includes(job.status);
  return <article className="overflow-hidden rounded-[1.8rem] border border-white/[0.08] bg-white/[0.03]">
    <div className={`relative aspect-video overflow-hidden bg-gradient-to-br ${model.gradient} bg-[#0c0c12]`}>
      {job.status === "completed" ? <video className="h-full w-full object-cover" controls preload="metadata" src={`/api/generations/${job.id}/content`} /> : <div className="absolute inset-0 grid place-items-center"><div className="text-center">{active ? <><div className="relative mx-auto size-20"><div className="absolute inset-0 rounded-full border border-white/10" /><div className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-violet-300" /><div className="grid h-full place-items-center text-sm font-black">{job.progress}%</div></div><p className="mt-4 text-xs font-bold uppercase tracking-[0.18em] text-white/45">{job.status}</p></> : <><TriangleAlert className="mx-auto size-8 text-red-300" /><p className="mt-3 text-sm font-bold">Render failed</p></>}</div></div>}
      <div className="absolute left-4 top-4 rounded-full border border-white/10 bg-black/50 px-3 py-1 text-[10px] font-black uppercase tracking-[0.14em] backdrop-blur-xl">{model.name}</div>
    </div>
    <div className="p-5"><div className="flex items-center justify-between text-[10px] font-black uppercase tracking-[0.14em] text-white/32"><span>{job.aspectRatio} • {job.duration}s • {job.resolution}</span><span>{job.cost} cr</span></div><p className="mt-4 line-clamp-3 text-sm leading-6 text-white/68">{job.prompt}</p><div className="mt-5 flex items-center justify-between border-t border-white/[0.07] pt-4"><span className="text-xs text-white/30">{new Date(job.createdAt).toLocaleString()}</span>{job.status === "completed" && <a href={`/api/generations/${job.id}/content`} className="flex items-center gap-2 rounded-xl bg-white px-3 py-2 text-xs font-black text-black"><Download className="size-3.5" />Open</a>}{active && <Play className="size-4 text-violet-300" />}</div>{job.error && <p className="mt-3 rounded-xl bg-red-500/10 p-3 text-xs text-red-200">{job.error}</p>}</div>
  </article>;
}
