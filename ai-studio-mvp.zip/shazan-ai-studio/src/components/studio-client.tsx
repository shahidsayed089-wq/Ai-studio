"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, ChevronDown, CircleDollarSign, Image as ImageIcon, Loader2, MonitorPlay, Music2, Sparkles, WandSparkles } from "lucide-react";
import { calculateCost, MODELS } from "@/lib/catalog";
import type { GenerationInput, ProviderId } from "@/lib/types";

type Availability = Record<ProviderId, { configured: boolean; mode: "live" | "demo" | "offline" }>;

const starterPrompt = "A helmeted Indian superspy accelerates through a rain-soaked futuristic tunnel in Dubai at night, red laser grids flicker across the walls, grounded IMAX action realism";

export function StudioClient() {
  const router = useRouter();
  const [selectedId, setSelectedId] = useState("luma");
  const selected = MODELS.find((model) => model.provider === selectedId)!;
  const [availability, setAvailability] = useState<Availability | null>(null);
  const [form, setForm] = useState<GenerationInput>({ provider: "luma", model: "ray-2", prompt: starterPrompt, mode: "text-to-video", aspectRatio: "9:16", duration: 5, resolution: "720p", audio: false });
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => { fetch("/api/config").then((r) => r.json()).then((data) => setAvailability(data.providers)); }, []);
  const cost = useMemo(() => calculateCost(form), [form]);

  function choose(provider: ProviderId) {
    const model = MODELS.find((item) => item.provider === provider)!;
    setSelectedId(provider);
    setForm((current) => ({ ...current, provider, model: model.id, duration: model.durations[0] as 5 | 8 | 10 | 15, audio: current.audio && model.supportsAudio }));
  }

  async function enhance() {
    if (!form.prompt.trim()) return;
    setEnhancing(true);
    const response = await fetch("/api/prompt/enhance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt: form.prompt, aspectRatio: form.aspectRatio }) });
    const data = await response.json();
    if (response.ok) setForm({ ...form, prompt: data.prompt });
    setEnhancing(false);
  }

  async function generate() {
    setLoading(true); setError("");
    const response = await fetch("/api/generations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await response.json();
    setLoading(false);
    if (!response.ok) return setError(data.error || "Render could not start");
    router.push(`/library?focus=${data.job.id}`);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-[1500px] px-4 py-6 sm:px-7 lg:px-10 lg:py-10">
      <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
        <div><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-[11px] font-bold tracking-[0.16em] text-violet-200"><Sparkles className="size-3" /> MULTI-MODEL DIRECTOR</div><h1 className="text-4xl font-black tracking-[-0.045em] sm:text-5xl">Direct the impossible.</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-white/45">Switch engines without switching tabs. Your prompt, references, render status and credits stay in one production cockpit.</p></div>
        <div className="flex items-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.035] px-4 py-3 text-sm"><CircleDollarSign className="size-4 text-amber-300" /><span className="text-white/45">Estimated render</span><b>{cost} credits</b></div>
      </div>

      <section className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {MODELS.map((model) => {
          const active = selectedId === model.provider;
          const status = availability?.[model.provider]?.mode || "demo";
          return <button onClick={() => choose(model.provider)} key={model.id} className={`group relative overflow-hidden rounded-3xl border p-5 text-left transition duration-300 ${active ? "border-white/25 bg-white/[0.08] shadow-[0_20px_70px_rgba(0,0,0,.35)]" : "border-white/[0.07] bg-white/[0.025] hover:-translate-y-1 hover:bg-white/[0.05]"}`}>
            <div className={`absolute inset-0 bg-gradient-to-br ${model.gradient} opacity-80`} />
            <div className="relative"><div className="flex items-center justify-between"><span className="rounded-full border border-white/10 bg-black/20 px-2.5 py-1 text-[9px] font-black tracking-[0.14em] text-white/55">{model.badge}</span>{active && <div className="grid size-6 place-items-center rounded-full bg-white text-black"><Check className="size-3.5" /></div>}</div><h3 className="mt-7 text-xl font-black">{model.name}</h3><p className="mt-1 text-xs font-semibold text-white/42">{model.label}</p><div className="mt-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.12em]"><span className={`size-1.5 rounded-full ${status === "live" ? "bg-emerald-400" : status === "demo" ? "bg-amber-300" : "bg-red-400"}`} />{status}</div></div>
          </button>;
        })}
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.35fr_.65fr]">
        <section className="rounded-[2rem] border border-white/[0.08] bg-white/[0.03] p-4 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-lg font-black">Creative brief</h2><p className="mt-1 text-xs text-white/35">Describe the exact shot, action, lighting and camera behavior.</p></div><button onClick={enhance} disabled={enhancing} className="flex items-center gap-2 rounded-xl border border-violet-400/20 bg-violet-500/10 px-3 py-2 text-xs font-bold text-violet-200"><WandSparkles className="size-3.5" />{enhancing ? "Enhancing..." : "Cinematic enhance"}</button></div>
          <textarea value={form.prompt} onChange={(e) => setForm({ ...form, prompt: e.target.value })} className="mt-5 min-h-64 w-full resize-none rounded-3xl border border-white/[0.08] bg-black/25 p-5 text-[15px] leading-7 text-white outline-none focus:border-violet-400/35" />
          <div className="mt-4 flex justify-between text-xs text-white/28"><span>Specific camera language improves control.</span><span>{form.prompt.length}/5000</span></div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <SelectLabel title="Generation mode" icon={<MonitorPlay />}><select value={form.mode} onChange={(e) => setForm({ ...form, mode: e.target.value as GenerationInput["mode"] })} className="select-control"><option value="text-to-video">Text to video</option>{selected.supportsImage && <option value="image-to-video">Image to video</option>}</select></SelectLabel>
            {form.mode === "image-to-video" && <SelectLabel title="Reference image URL" icon={<ImageIcon />}><input value={form.imageUrl || ""} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://.../frame.jpg" className="select-control" /></SelectLabel>}
          </div>
          {error && <div className="mt-5 rounded-2xl border border-red-400/20 bg-red-500/10 p-4 text-sm text-red-200">{error}</div>}
          <button onClick={generate} disabled={loading || !form.prompt.trim()} className="mt-6 flex w-full items-center justify-center gap-3 rounded-2xl bg-white py-4 font-black text-black transition hover:scale-[1.005] disabled:opacity-50">{loading ? <Loader2 className="size-5 animate-spin" /> : <><WandSparkles className="size-5" />Generate with {selected.name}<span className="rounded-full bg-black/10 px-2 py-1 text-xs">{cost} cr</span></>}</button>
        </section>

        <aside className="space-y-5">
          <section className="rounded-[2rem] border border-white/[0.08] bg-white/[0.03] p-5 sm:p-6"><h2 className="text-lg font-black">Render controls</h2><div className="mt-6 space-y-5">
            <Control title="Aspect ratio"><div className="grid grid-cols-3 gap-2">{(["16:9", "9:16", "1:1"] as const).map((value) => <button key={value} onClick={() => setForm({ ...form, aspectRatio: value })} className={`rounded-xl border px-2 py-3 text-xs font-black ${form.aspectRatio === value ? "border-white/30 bg-white text-black" : "border-white/[0.08] bg-white/[0.03] text-white/45"}`}>{value}</button>)}</div></Control>
            <Control title="Duration"><div className="grid grid-cols-4 gap-2">{selected.durations.map((value) => <button key={value} onClick={() => setForm({ ...form, duration: value as 5 | 8 | 10 | 15 })} className={`rounded-xl border py-2.5 text-xs font-bold ${form.duration === value ? "border-violet-400/40 bg-violet-500/15 text-violet-100" : "border-white/[0.08] text-white/40"}`}>{value}s</button>)}</div></Control>
            <Control title="Resolution"><div className="grid grid-cols-2 gap-2">{(["720p", "1080p"] as const).map((value) => <button key={value} onClick={() => setForm({ ...form, resolution: value })} className={`rounded-xl border py-3 text-xs font-bold ${form.resolution === value ? "border-violet-400/40 bg-violet-500/15" : "border-white/[0.08] text-white/40"}`}>{value}</button>)}</div></Control>
            {selected.supportsAudio && <button onClick={() => setForm({ ...form, audio: !form.audio })} className="flex w-full items-center justify-between rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4"><div className="flex items-center gap-3"><Music2 className="size-4 text-cyan-300" /><div className="text-left"><p className="text-sm font-bold">Native audio</p><p className="text-[11px] text-white/35">Sound, ambience and dialogue</p></div></div><div className={`h-6 w-11 rounded-full p-1 transition ${form.audio ? "bg-emerald-400" : "bg-white/10"}`}><div className={`size-4 rounded-full bg-white transition ${form.audio ? "translate-x-5" : ""}`} /></div></button>}
          </div></section>
          <section className="rounded-[2rem] border border-white/[0.08] bg-gradient-to-br from-violet-500/10 to-blue-500/5 p-6"><p className="text-xs font-black tracking-[0.16em] text-white/38">DIRECTOR NOTE</p><p className="mt-4 text-sm leading-6 text-white/60">For continuity, repeat wardrobe, lens, lighting and weather details in every shot. Models remember prompts, not your secret screenplay brain.</p></section>
        </aside>
      </div>
    </div>
  );
}

function Control({ title, children }: { title: string; children: React.ReactNode }) { return <div><p className="mb-2 text-[11px] font-black uppercase tracking-[0.16em] text-white/35">{title}</p>{children}</div>; }
function SelectLabel({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) { return <label><span className="mb-2 flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.14em] text-white/35">{icon}{title}</span><div className="relative">{children}<ChevronDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-white/30" /></div></label>; }
