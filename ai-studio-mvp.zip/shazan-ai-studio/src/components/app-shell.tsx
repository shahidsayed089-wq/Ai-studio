"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { BarChart3, Coins, Film, LogOut, Menu, Sparkles, X } from "lucide-react";
import { useState } from "react";
import { Logo } from "./logo";

type SafeUser = { id: string; name: string; email: string; credits: number; role: "user" | "admin" };

const nav = [
  { href: "/studio", label: "Create", icon: Sparkles },
  { href: "/library", label: "My renders", icon: Film },
  { href: "/billing", label: "Credits", icon: Coins },
];

export function AppShell({ user, children }: { user: SafeUser; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const items = user.role === "admin" ? [...nav, { href: "/admin", label: "Command center", icon: BarChart3 }] : nav;

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_12%_5%,rgba(124,58,237,.14),transparent_32%),radial-gradient(circle_at_90%_18%,rgba(37,99,235,.12),transparent_28%),linear-gradient(rgba(255,255,255,.018)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.018)_1px,transparent_1px)] bg-[size:auto,auto,54px_54px,54px_54px]" />

      <aside className="fixed inset-y-0 left-0 z-40 hidden w-72 border-r border-white/[0.07] bg-black/25 p-6 backdrop-blur-2xl lg:flex lg:flex-col">
        <Logo />
        <nav className="mt-12 space-y-2">
          {items.map((item) => {
            const active = pathname.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition ${active ? "border border-violet-400/20 bg-violet-500/15 text-white shadow-[0_10px_35px_rgba(124,58,237,.13)]" : "text-white/48 hover:bg-white/[0.05] hover:text-white"}`}>
                <Icon className="size-4" /> {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto rounded-3xl border border-white/[0.08] bg-white/[0.035] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/35">Available</p>
              <p className="mt-1 text-xl font-black">{user.credits} <span className="text-xs font-medium text-white/40">credits</span></p>
            </div>
            <Coins className="size-5 text-amber-300" />
          </div>
          <div className="mt-4 border-t border-white/[0.07] pt-4">
            <p className="truncate text-sm font-semibold">{user.name}</p>
            <p className="truncate text-xs text-white/35">{user.email}</p>
            <button onClick={logout} className="mt-4 flex items-center gap-2 text-xs font-semibold text-white/45 hover:text-white"><LogOut className="size-3.5" /> Sign out</button>
          </div>
        </div>
      </aside>

      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/[0.07] bg-[#07070b]/80 px-4 backdrop-blur-2xl lg:hidden">
        <Logo />
        <button onClick={() => setOpen(true)} className="grid size-10 place-items-center rounded-xl bg-white/[0.06]"><Menu className="size-5" /></button>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xl lg:hidden">
          <div className="absolute inset-y-0 right-0 w-[86%] max-w-sm border-l border-white/10 bg-[#0b0b11] p-6">
            <div className="flex items-center justify-between"><Logo /><button onClick={() => setOpen(false)}><X /></button></div>
            <nav className="mt-10 space-y-2">
              {items.map((item) => <Link onClick={() => setOpen(false)} key={item.href} href={item.href} className="flex items-center gap-3 rounded-2xl bg-white/[0.04] px-4 py-4 font-semibold"><item.icon className="size-5" />{item.label}</Link>)}
            </nav>
            <div className="mt-8 rounded-2xl border border-white/10 p-4"><b>{user.credits} credits</b><p className="mt-1 text-sm text-white/40">{user.email}</p></div>
          </div>
        </div>
      )}

      <main className="relative min-h-screen lg:pl-72">{children}</main>
    </div>
  );
}
