"use client";

import { useState } from "react";
import { Check, Coins, Loader2, ShieldCheck, Zap } from "lucide-react";
import { CREDIT_PACKS } from "@/lib/catalog";

export function BillingClient({ credits }: { credits: number }) {
  const [loading, setLoading] = useState("");
  const [message, setMessage] = useState("");
  async function topup(packId: string) {
    setLoading(packId); setMessage("");
    const response = await fetch("/api/billing/topup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ packId }) });
    const data = await response.json(); setLoading("");
    setMessage(response.ok ? `${data.creditsAdded} credits added in demo billing mode.` : data.error);
    if (response.ok) window.location.reload();
  }
  return <div className="mx-auto max-w-6xl px-4 py-8 sm:px-7 lg:px-10 lg:py-12">
    <div className="grid gap-6 lg:grid-cols-[.8fr_1.2fr] lg:items-end"><div><div className="inline-flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-500/10 px-3 py-1 text-[10px] font-black tracking-[0.16em] text-amber-200"><Coins className="size-3" /> PREPAID, NO SURPRISES</div><h1 className="mt-5 text-5xl font-black tracking-[-0.05em]">Fuel the render farm.</h1><p className="mt-4 text-sm leading-6 text-white/45">Credits are deducted only after a provider accepts the job. Failed jobs are refunded automatically.</p></div><div className="rounded-[2rem] border border-white/[0.08] bg-white/[0.04] p-7"><p className="text-xs font-black uppercase tracking-[0.16em] text-white/35">Current balance</p><p className="mt-3 text-6xl font-black">{credits}</p><p className="mt-2 text-sm text-white/35">Available production credits</p></div></div>
    <div className="mt-10 grid gap-5 md:grid-cols-3">{CREDIT_PACKS.map((pack, index) => <div key={pack.id} className={`relative rounded-[2rem] border p-6 ${index === 1 ? "border-violet-400/35 bg-violet-500/[0.09] shadow-[0_25px_80px_rgba(124,58,237,.16)]" : "border-white/[0.08] bg-white/[0.03]"}`}>{index === 1 && <span className="absolute right-5 top-5 rounded-full bg-white px-2.5 py-1 text-[9px] font-black text-black">POPULAR</span>}<p className="text-sm font-black">{pack.name}</p><p className="mt-5 text-4xl font-black">{pack.credits + pack.bonus}</p><p className="mt-1 text-xs text-white/35">credits {pack.bonus ? `including ${pack.bonus} bonus` : ""}</p><p className="mt-6 text-2xl font-black">₹{pack.price.toLocaleString("en-IN")}</p><button onClick={() => topup(pack.id)} disabled={Boolean(loading)} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-white py-3 text-sm font-black text-black">{loading === pack.id ? <Loader2 className="size-4 animate-spin" /> : <><Zap className="size-4" />Add credits</>}</button><ul className="mt-6 space-y-3 text-xs text-white/48">{["All video models", "Automatic failure refunds", "Generation history"].map((item) => <li key={item} className="flex items-center gap-2"><Check className="size-3.5 text-emerald-300" />{item}</li>)}</ul></div>)}</div>
    {message && <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm">{message}</div>}
    <div className="mt-8 flex items-start gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.025] p-5"><ShieldCheck className="mt-0.5 size-5 text-emerald-300" /><div><p className="text-sm font-bold">Razorpay-ready billing boundary</p><p className="mt-1 text-xs leading-5 text-white/35">This MVP uses demo top-ups for testing. Replace the top-up endpoint with Razorpay order creation and signature verification before launch.</p></div></div>
  </div>;
}
