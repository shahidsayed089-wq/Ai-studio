import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { LibraryClient } from "@/components/library-client";
import { getCurrentUser } from "@/lib/auth";

export default async function LibraryPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return <AppShell user={user}><LibraryClient /></AppShell>;
}
