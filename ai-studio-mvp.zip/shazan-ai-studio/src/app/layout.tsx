import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Shazan AI Studio | Multi-model video generation",
  description: "Generate cinematic AI video with Sora, Veo, Luma, Kling and Seedance from one production dashboard.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
