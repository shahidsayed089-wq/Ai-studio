import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { AdminClient } from "@/components/admin-client";
import { getCurrentUser } from "@/lib/auth";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/studio");
  return <AppShell user={user}><AdminClient /></AppShell>;
}
