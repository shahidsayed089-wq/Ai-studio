import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { BillingClient } from "@/components/billing-client";
import { getCurrentUser } from "@/lib/auth";

export default async function BillingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return <AppShell user={user}><BillingClient credits={user.credits} /></AppShell>;
}
