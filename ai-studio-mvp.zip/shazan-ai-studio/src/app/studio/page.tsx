import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { StudioClient } from "@/components/studio-client";
import { getCurrentUser } from "@/lib/auth";

export default async function StudioPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return <AppShell user={user}><StudioClient /></AppShell>;
}
