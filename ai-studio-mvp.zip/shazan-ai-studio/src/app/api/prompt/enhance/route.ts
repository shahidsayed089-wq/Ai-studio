import { NextResponse } from "next/server";
import { z } from "zod";
import { enhancePrompt } from "@/lib/prompt";

const schema = z.object({ prompt: z.string().min(3).max(4000), aspectRatio: z.string().default("16:9") });
export async function POST(request: Request) {
  try {
    const input = schema.parse(await request.json());
    return NextResponse.json({ prompt: enhancePrompt(input.prompt, input.aspectRatio) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not enhance prompt" }, { status: 400 });
  }
}
