import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { createSession } from "@/lib/auth";
import { mutateDb } from "@/lib/db";

const schema = z.object({
  name: z.string().min(2).max(60),
  email: z.string().email(),
  password: z.string().min(8).max(100),
});

export async function POST(request: Request) {
  try {
    const input = schema.parse(await request.json());
    const user = await mutateDb(async (db) => {
      if (db.users.some((item) => item.email.toLowerCase() === input.email.toLowerCase())) {
        throw new Error("An account with this email already exists");
      }
      const created = {
        id: crypto.randomUUID(),
        name: input.name,
        email: input.email.toLowerCase(),
        passwordHash: await bcrypt.hash(input.password, 10),
        credits: 80,
        role: "user" as const,
        createdAt: new Date().toISOString(),
      };
      db.users.push(created);
      db.transactions.push({
        id: crypto.randomUUID(), userId: created.id, amount: 80, type: "topup",
        description: "Welcome credits", createdAt: created.createdAt,
      });
      return created;
    });
    await createSession(user.id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Registration failed" }, { status: 400 });
  }
}
