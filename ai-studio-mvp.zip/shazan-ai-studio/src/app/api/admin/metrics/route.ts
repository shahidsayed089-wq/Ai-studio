import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { readDb } from "@/lib/db";

export async function GET() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 });
  const db = await readDb();
  const completed = db.jobs.filter((job) => job.status === "completed").length;
  const failed = db.jobs.filter((job) => job.status === "failed").length;
  const creditsSpent = Math.abs(db.transactions.filter((tx) => tx.type === "generation").reduce((sum, tx) => sum + tx.amount, 0));
  const byProvider = Object.fromEntries(["sora", "veo", "luma", "kling", "seedance"].map((id) => [id, db.jobs.filter((job) => job.provider === id).length]));
  return NextResponse.json({
    metrics: { users: db.users.length, generations: db.jobs.length, completed, failed, creditsSpent, successRate: db.jobs.length ? Math.round((completed / db.jobs.length) * 100) : 0, byProvider },
    recentJobs: db.jobs.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 10),
  });
}
