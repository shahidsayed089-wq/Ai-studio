import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { calculateCost, getModel } from "@/lib/catalog";
import { mutateDb, readDb } from "@/lib/db";
import { getProvider } from "@/lib/providers";
import type { GenerationInput, GenerationJob, ProviderId } from "@/lib/types";

const schema = z.object({
  provider: z.enum(["sora", "veo", "luma", "kling", "seedance"]),
  model: z.string().min(2),
  prompt: z.string().min(10).max(5000),
  negativePrompt: z.string().max(1000).optional(),
  mode: z.enum(["text-to-video", "image-to-video"]),
  imageUrl: z.string().url().optional().or(z.literal("")),
  aspectRatio: z.enum(["16:9", "9:16", "1:1"]),
  duration: z.union([z.literal(5), z.literal(8), z.literal(10), z.literal(15)]),
  resolution: z.enum(["720p", "1080p"]),
  audio: z.boolean(),
  seed: z.number().int().positive().optional(),
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const db = await readDb();
  const jobs = db.jobs.filter((job) => job.userId === user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return NextResponse.json({ jobs });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in first" }, { status: 401 });
  try {
    const parsed = schema.parse(await request.json());
    const input: GenerationInput = { ...parsed, imageUrl: parsed.imageUrl || undefined };
    const model = getModel(input.model);
    if (model.provider !== input.provider) throw new Error("Selected model does not belong to this provider");
    if (input.mode === "image-to-video" && !input.imageUrl) throw new Error("Image-to-video requires a public image URL");
    const cost = calculateCost(input);
    const latest = await readDb();
    const currentUser = latest.users.find((item) => item.id === user.id);
    if (!currentUser || currentUser.credits < cost) throw new Error(`Not enough credits. This render needs ${cost} credits.`);

    const provider = getProvider(input.provider as ProviderId);
    if (!provider.configured()) throw new Error(`${input.provider} is not configured on this server`);
    const created = await provider.create(input);
    const now = new Date().toISOString();
    const job: GenerationJob = {
      ...input,
      id: crypto.randomUUID(),
      userId: user.id,
      status: created.status,
      progress: created.progress || 5,
      cost,
      providerJobId: created.providerJobId,
      providerPayload: created.raw,
      createdAt: now,
      updatedAt: now,
    };

    await mutateDb((db) => {
      const dbUser = db.users.find((item) => item.id === user.id);
      if (!dbUser || dbUser.credits < cost) throw new Error("Credit balance changed. Please retry.");
      dbUser.credits -= cost;
      db.jobs.push(job);
      db.transactions.push({
        id: crypto.randomUUID(), userId: user.id, amount: -cost, type: "generation",
        description: `${model.name} render`, createdAt: now,
      });
    });
    return NextResponse.json({ job }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Generation could not start" }, { status: 400 });
  }
}
