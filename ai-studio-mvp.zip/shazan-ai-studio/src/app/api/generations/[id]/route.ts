import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { mutateDb, readDb } from "@/lib/db";
import { getProvider } from "@/lib/providers";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const db = await readDb();
  let job = db.jobs.find((item) => item.id === id && item.userId === user.id);
  if (!job) return NextResponse.json({ error: "Generation not found" }, { status: 404 });

  if (["queued", "processing"].includes(job.status) && job.providerJobId) {
    try {
      const provider = getProvider(job.provider);
      const update = await provider.status(job.providerJobId, job);
      job = await mutateDb((liveDb) => {
        const current = liveDb.jobs.find((item) => item.id === id && item.userId === user.id);
        if (!current) throw new Error("Generation disappeared");
        const wasTerminal = ["completed", "failed"].includes(current.status);
        current.status = update.status;
        current.progress = update.progress;
        current.outputUrl = update.outputUrl || current.outputUrl;
        current.thumbnailUrl = update.thumbnailUrl || current.thumbnailUrl;
        current.error = update.error;
        current.providerPayload = update.raw || current.providerPayload;
        current.updatedAt = new Date().toISOString();
        if (!wasTerminal && update.status === "failed") {
          const account = liveDb.users.find((item) => item.id === current.userId);
          if (account) account.credits += current.cost;
          liveDb.transactions.push({
            id: crypto.randomUUID(), userId: current.userId, amount: current.cost, type: "refund",
            description: `Automatic refund for failed ${current.provider} render`, createdAt: current.updatedAt,
          });
        }
        return current;
      });
    } catch (error) {
      // Temporary provider errors do not fail the job immediately.
      job = { ...job, error: error instanceof Error ? error.message : "Status check failed" };
    }
  }
  return NextResponse.json({ job });
}
