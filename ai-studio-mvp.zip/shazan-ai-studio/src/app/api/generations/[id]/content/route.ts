import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { readDb } from "@/lib/db";
import { getProvider } from "@/lib/providers";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const db = await readDb();
  const job = db.jobs.find((item) => item.id === id && item.userId === user.id);
  if (!job || job.status !== "completed") return NextResponse.json({ error: "Video is not ready" }, { status: 404 });
  if (job.outputUrl) return NextResponse.redirect(job.outputUrl);
  const provider = getProvider(job.provider);
  if (provider.content && job.providerJobId) {
    const response = await provider.content(job.providerJobId);
    return new NextResponse(response.body, { status: response.status, headers: response.headers });
  }
  return NextResponse.json({ error: "No output asset available" }, { status: 404 });
}
