import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { CREDIT_PACKS } from "@/lib/catalog";
import { mutateDb } from "@/lib/db";

const schema = z.object({ packId: z.string() });
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const { packId } = schema.parse(await request.json());
    const pack = CREDIT_PACKS.find((item) => item.id === packId);
    if (!pack) throw new Error("Credit pack not found");
    if (process.env.ENABLE_DEMO_TOPUPS === "false") throw new Error("Connect Razorpay before enabling live top-ups");
    const total = pack.credits + pack.bonus;
    await mutateDb((db) => {
      const account = db.users.find((item) => item.id === user.id);
      if (!account) throw new Error("Account not found");
      account.credits += total;
      db.transactions.push({
        id: crypto.randomUUID(), userId: user.id, amount: total, type: "topup",
        description: `${pack.name} demo top-up`, createdAt: new Date().toISOString(),
      });
    });
    return NextResponse.json({ ok: true, creditsAdded: total });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Top-up failed" }, { status: 400 });
  }
}
