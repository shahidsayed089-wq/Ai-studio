import { NextResponse } from "next/server";
import { providerAvailability } from "@/lib/providers";

export async function GET() {
  return NextResponse.json({ providers: providerAvailability(), demoFallback: process.env.DEMO_PROVIDER_FALLBACK !== "false" });
}
