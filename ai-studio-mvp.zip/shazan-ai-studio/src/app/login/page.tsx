import { redirect } from "next/navigation";
import { LoginClient } from "@/components/login-client";
import { Logo } from "@/components/logo";
import { getCurrentUser } from "@/lib/auth";

export default async function LoginPage() {
  const user = await getCurrentUser();
  if (user) redirect("/studio");
  return <main className="relative grid min-h-screen place-items-center overflow-hidden bg-[#07070b] px-4 py-12 text-white"><div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_18%,rgba(124,58,237,.24),transparent_30%),radial-gradient(circle_at_20%_80%,rgba(14,165,233,.13),transparent_25%)]" /><div className="relative w-full"><div className="mx-auto mb-8 w-fit"><Logo /></div><LoginClient /></div></main>;
}
